package ua.kiev.prog;

import java.util.List;

public class UserLisr {
    private final List<User> list;

    public UserLisr(List<User> list) {
        this.list = list;
    }
}
